import re
from collections import defaultdict, Counter
import sys

class NgramCharacterModel:
    def __init__(self, corpus, n=2):
        # TODO: Initialize the class variables
        pass
    
    def _train(self, corpus):
        # TODO: Train the language model on the given corpus input
        pass

    def _generate_word(self, prefix):
        # TODO: Given a prefix, generate the most probable word that it completes to
        pass

    def predict_top_words(self, prefix, top_k=10):
        # TODO: Given a prefix, return the top_k most probable words from the corpus it completes to 
        pass
    
    def _word_probability(self, word):
        # TODO: Calculates the probability of the word, based on the trigram probabilities
        pass